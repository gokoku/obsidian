#スクリプトを実行し、システムコンソール画面がなければ「Window」→「Toggle System Console」メニュー実行。
#システムコンソール画面にPythonの著作権が表示される。

import sys

print(sys.copyright)
