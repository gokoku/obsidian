#PyTest.blendファイルを開く。
#スクリプトを実行し、システムコンソール画面がなければ「Window」→「Toggle System Console」メニュー実行。
#システムコンソール画面にメッシュ情報が表示される。

import bpy


for m in range(len(bpy.data.meshes)):
    mesh = bpy.data.meshes[m]
    print("Mesh Object {0}, Polygon Num {1}".format(m,len(mesh.polygons)))
    for p in range(len(mesh.polygons)):
        verts = mesh.polygons[p].vertices
        s = ",".join([str(v) for v in verts])
        print("Polygon {}, Index({})".format(p,s));
